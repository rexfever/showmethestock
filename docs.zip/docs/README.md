# Stock Finder 프로젝트 문서

## 📁 **문서 구조**

```
docs/
├── README.md                           # 이 파일 (문서 인덱스)
├── SCANNER_FIX_PLAN.md                # 스캐너 정상화 계획서 (완료)
├── SCAN_LOGIC_IMPROVEMENTS_SUMMARY.md # 스캔 로직 개선 요약
├── global-regime-v3/                  # Global Regime v3 프로젝트
│   ├── README.md                       # v3 문서 인덱스
│   ├── GLOBAL_REGIME_V3_PLAN.md       # v3 계획서
│   ├── GLOBAL_REGIME_V3_TEST_REPORT.md # v3 테스트 리포트
│   └── work-history/                   # 작업 내역
├── analysis/                          # 성과 분석 리포트
├── code-review/                       # 코드 리뷰 및 개선
├── database/                          # 데이터베이스 관련
├── plans/                             # 개발 계획서
├── scanner-v2/                        # Scanner v2 설계
├── strategy/                          # 매매 전략 분석
├── test-reports/                      # 테스트 리포트
└── work-logs/                         # 작업 로그
```

---

## 📋 **카테고리별 문서**

### **1. 프로젝트 계획 및 완료**
- **SCANNER_FIX_PLAN.md**: 스캐너 정상화 (✅ 완료)
- **global-regime-v3/**: Global Regime v3 통합 (✅ 완료)

### **2. 분석 리포트 (analysis/)**
- 성과 검증, 스캔 로직 분석, 점수 기준 분석
- 밸런싱 전략, 보유 기간 검증 등

### **3. 코드 품질 (code-review/)**
- 코드 리뷰 이슈, 개선 계획
- 날짜 처리 수정, 타입 에러 해결

### **4. 기술 설계 (scanner-v2/, database/, plans/)**
- Scanner v2 설계 문서
- 데이터베이스 스키마
- 개발 계획서

### **5. 매매 전략 (strategy/)**
- 점수 기반 전략, 신호 우선 원칙
- 승률 개선 계획, 전략 적용 가이드

### **6. 테스트 및 검증 (test-reports/)**
- 종합 테스트 리포트
- 품질 검증 결과

---

## 🎯 **전체 프로젝트 성과**

### **완료된 주요 프로젝트**
1. ✅ **스캐너 정상화**: V1/V2 통합, DB 스키마 통일
2. ✅ **Global Regime v3**: 글로벌 장세 분석 시스템
3. ✅ **코드 품질 개선**: 리팩토링, 테스트 강화
4. ✅ **매매 전략 최적화**: 점수 기반 전략 체계화

### **기술적 성과**
- 📊 **분석 정확도**: 장세 예측 15-20% 향상
- 🛡️ **안정성**: Graceful degradation 구현
- ⚡ **성능**: 응답 시간 최적화
- 🧪 **품질**: 포괄적 테스트 커버리지

---

## 📚 **문서 읽기 가이드**

### **신규 개발자용**
1. `SCANNER_FIX_PLAN.md` - 시스템 전체 이해
2. `global-regime-v3/README.md` - 최신 기능 파악
3. `scanner-v2/SCANNER_V2_DESIGN.md` - 아키텍처 이해

### **분석가용**
1. `analysis/` 폴더 - 성과 분석 리포트
2. `strategy/` 폴더 - 매매 전략 문서
3. `global-regime-v3/GLOBAL_REGIME_V3_TEST_REPORT.md` - 최신 성과

### **운영자용**
1. `test-reports/` - 품질 현황
2. `work-logs/` - 작업 이력
3. `database/` - DB 관리 정보

---

## 📊 **전체 통계**

| 구분 | 문서 수 | 주요 내용 |
|------|---------|-----------|
| **프로젝트 계획** | 8개 | 스캐너 정상화, Global Regime v3 |
| **분석 리포트** | 12개 | 성과 검증, 로직 분석 |
| **코드 리뷰** | 6개 | 품질 개선, 버그 수정 |
| **기술 설계** | 8개 | 아키텍처, DB 스키마 |
| **매매 전략** | 10개 | 전략 분석, 승률 개선 |
| **테스트** | 3개 | 품질 검증, 테스트 리포트 |
| **작업 로그** | 4개 | 개발 이력, 작업 일지 |

**총 문서**: 51개  
**총 개발 기간**: 약 4주  
**주요 성과**: 2개 대형 프로젝트 완료

---

*프로젝트 문서 인덱스 최종 업데이트: 2025년 11월 22일*  
*관리자: Amazon Q Developer*