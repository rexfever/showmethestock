# 서버 DB 접속 정보

## 📊 PostgreSQL 접속 정보

### 실제 서버 DB 설정
```bash
# Host: localhost
# Database: stockfinder
# User: stockfinder
# Password: stockfinder_pass
# Connection String: postgresql://stockfinder:stockfinder_pass@localhost/stockfinder
```

### DB 접속 명령어
```bash
# 기본 접속
PGPASSWORD=stockfinder_pass psql -U stockfinder -d stockfinder

# 쿼리 실행
PGPASSWORD=stockfinder_pass psql -U stockfinder -d stockfinder -c "SELECT COUNT(*) FROM scan_rank WHERE date = '2025-11-21';"

# 스캔 데이터 확인
PGPASSWORD=stockfinder_pass psql -U stockfinder -d stockfinder -c "SELECT code, name, score, scanner_version FROM scan_rank WHERE date = '2025-11-21' ORDER BY score DESC;"
```

### 환경변수 파일 위치
```bash
# 서버 환경변수 파일
/home/ubuntu/showmethestock/backend/.env

# DB 설정 확인
grep DATABASE_URL /home/ubuntu/showmethestock/backend/.env
```

### 백업 명령어
```bash
# 백업 생성
PGPASSWORD=stockfinder_pass pg_dump -U stockfinder -h localhost stockfinder | gzip > backup_$(date +%Y%m%d).sql.gz

# 백업 복원
PGPASSWORD=stockfinder_pass gunzip < backup_file.sql.gz | psql -U stockfinder stockfinder
```

### 주요 테이블
- `scan_rank`: 스캔 결과 저장 (date, code, scanner_version 복합키)
- `market_conditions`: 시장 상황 저장
- `users`: 사용자 정보
- `market_regime_daily`: 레짐 분석 결과

---
*업데이트: 2025-11-23*
*작성자: Amazon Q Developer*