# Stock Finder 개발 환경 설정 매뉴얼

## 📋 시스템 요구사항

### 필수 소프트웨어
- **Python**: 3.8+ (권장: 3.9+)
- **Node.js**: 16+ (권장: 18+)
- **PostgreSQL**: 13+ (로컬 개발용)
- **Git**: 최신 버전

### 운영체제 지원
- **macOS**: 10.15+
- **Linux**: Ubuntu 20.04+, CentOS 8+
- **Windows**: WSL2 권장

## 🚀 프로젝트 구조

```
stock-finder/
├── backend/           # FastAPI 백엔드
├── frontend/          # Next.js 프론트엔드
├── cache/            # 데이터 캐시
├── docs/             # 문서
├── scripts/          # 배포/운영 스크립트
├── terraform/        # AWS 인프라
└── manuals/          # 매뉴얼
```

## 🔧 로컬 개발 환경 설정

### 1. 저장소 클론
```bash
git clone <repository-url>
cd stock-finder
```

### 2. 백엔드 설정

#### Python 가상환경 생성
```bash
cd backend
python -m venv venv

# macOS/Linux
source venv/bin/activate

# Windows
venv\Scripts\activate
```

#### 의존성 설치
```bash
pip install -r requirements.txt
```

#### 환경변수 설정
```bash
cp .env.example .env
```

**필수 환경변수 설정:**
```bash
# Kiwoom API (한국투자증권)
APP_KEY=your_kiwoom_app_key
APP_SECRET=your_kiwoom_app_secret

# Alpha Vantage API (미국 데이터)
ALPHA_VANTAGE_API_KEY=your_alpha_vantage_key

# PostgreSQL
DATABASE_URL=postgresql://username:password@localhost:5432/stock_finder
```

#### 데이터베이스 설정
```bash
# PostgreSQL 설치 (macOS)
brew install postgresql
brew services start postgresql

# 데이터베이스 생성
createdb stock_finder

# 마이그레이션 실행
python -c "from db import create_tables; create_tables()"
```

#### 백엔드 실행
```bash
python main.py
# 또는
uvicorn main:app --host 0.0.0.0 --port 8010 --reload
```

### 3. 프론트엔드 설정

#### Node.js 의존성 설치
```bash
cd frontend
npm install
```

#### 환경변수 설정
```bash
cp .env.local.example .env.local
```

**필수 환경변수:**
```bash
NEXT_PUBLIC_API_URL=http://localhost:8010
NEXT_PUBLIC_KAKAO_APP_KEY=your_kakao_app_key
```

#### 프론트엔드 실행
```bash
npm run dev
```

## 🔑 API 키 발급

### 1. Kiwoom API (한국투자증권)
1. [한국투자증권 KIS Developers](https://apiportal.koreainvestment.com/) 접속
2. 회원가입 및 앱 등록
3. APP_KEY, APP_SECRET 발급

### 2. Alpha Vantage API
1. [Alpha Vantage](https://www.alphavantage.co/support/#api-key) 접속
2. 무료 API 키 발급 (일일 500회 제한)

### 3. Kakao API (선택사항)
1. [Kakao Developers](https://developers.kakao.com/) 접속
2. 앱 생성 및 JavaScript 키 발급

## 📊 데이터베이스 스키마

### 주요 테이블
- `users`: 사용자 정보
- `scan_rank`: 스캔 결과
- `market_conditions`: 시장 상황
- `market_regime_daily`: 레짐 분석 결과
- `scanner_settings`: 스캐너 설정

### 초기 데이터 설정
```bash
cd backend
python migrations/create_market_regime_daily.py
python migrations/extend_market_conditions.py
```

## 🧪 테스트 실행

### 백엔드 테스트
```bash
cd backend
python -m pytest tests/ -v
```

### 프론트엔드 테스트
```bash
cd frontend
npm test
```

## 🔄 개발 워크플로우

### 1. 기능 개발
```bash
git checkout -b feature/new-feature
# 개발 작업
git add .
git commit -m "feat: 새로운 기능 추가"
git push origin feature/new-feature
```

### 2. 코드 품질 확인
```bash
# 백엔드 린트
cd backend
python -m flake8 .

# 프론트엔드 린트
cd frontend
npm run lint
```

### 3. 로컬 테스트
```bash
# 백엔드 서버 실행
cd backend && python main.py

# 프론트엔드 서버 실행
cd frontend && npm run dev

# 브라우저에서 http://localhost:3000 접속
```

## 🐛 트러블슈팅

### 자주 발생하는 문제

#### 1. Python 의존성 충돌
```bash
pip install --upgrade pip
pip install -r requirements.txt --force-reinstall
```

#### 2. PostgreSQL 연결 오류
```bash
# PostgreSQL 서비스 확인
brew services list | grep postgresql

# 연결 테스트
psql -h localhost -U username -d stock_finder
```

#### 3. API 키 오류
- `.env` 파일 경로 확인
- API 키 유효성 검증
- 요청 한도 확인

#### 4. 포트 충돌
```bash
# 포트 사용 확인
lsof -i :8010  # 백엔드
lsof -i :3000  # 프론트엔드

# 프로세스 종료
kill -9 <PID>
```

## 📁 중요 파일 설명

### 백엔드
- `main.py`: FastAPI 앱 진입점
- `kiwoom_api.py`: 한국투자증권 API 래퍼
- `market_analyzer.py`: 시장 분석 엔진
- `scanner.py`: 종목 스캔 로직
- `scheduler.py`: 자동 스케줄러

### 프론트엔드
- `pages/_app.js`: Next.js 앱 설정
- `pages/index.js`: 메인 페이지
- `pages/customer-scanner.js`: 스캐너 페이지
- `components/`: 재사용 컴포넌트

### 설정 파일
- `backend/.env`: 백엔드 환경변수
- `frontend/.env.local`: 프론트엔드 환경변수
- `backend/requirements.txt`: Python 의존성
- `frontend/package.json`: Node.js 의존성

## 🔒 보안 고려사항

### API 키 관리
- `.env` 파일을 Git에 커밋하지 않음
- 프로덕션에서는 AWS Parameter Store 사용
- API 키 정기적 로테이션

### 데이터베이스 보안
- 강력한 패스워드 사용
- SSL 연결 활성화
- 정기적 백업

## 📞 지원

### 문제 발생 시
1. 로그 파일 확인 (`backend.log`, `frontend.log`)
2. GitHub Issues 검색
3. 개발팀 문의

### 유용한 명령어
```bash
# 전체 시스템 상태 확인
./monitor.sh

# 로그 실시간 모니터링
tail -f backend.log

# 캐시 클리어
rm -rf cache/*
```

---

**작성일**: 2025-11-23  
**버전**: 1.0  
**작성자**: Development Team