# DB 연결 문제 해결 가이드

## 📋 개요

이 문서는 stock-finder 프로젝트의 PostgreSQL 데이터베이스 연결 문제를 해결하기 위한 가이드입니다.

---

## 🔍 현재 DB 설정 (work-logs 기준)

### 올바른 설정
```bash
# .env 파일
DATABASE_URL=postgresql://rexsmac@localhost:5432/stock_finder
POSTGRES_DSN=postgresql://rexsmac@localhost:5432/stock_finder
```

### 데이터베이스명
- **올바름**: `stock_finder`
- **잘못됨**: `stockfinder`

---

## 🛠️ 문제 해결 단계

### 1. DB 연결 상태 확인

```bash
# DB 연결 확인 스크립트 실행
python ~/workspace/stock-finder/check_db_connection.py
```

**예상 출력:**
```
📊 DB 연결 정보 확인
DATABASE_URL: postgresql://rexsmac@localhost:5432/stock_finder
🔄 DB 연결 테스트 중...
✅ PostgreSQL 연결 성공: PostgreSQL 16.x
✅ market_regime_daily 테이블 존재
```

### 2. 일반적인 문제 및 해결

#### 문제 1: `database "stock_finder" does not exist`

**해결:**
```bash
# 데이터베이스 생성
psql postgres -c "CREATE DATABASE stock_finder;"

# 확인
psql -l | grep stock_finder
```

#### 문제 2: `role "user" does not exist`

**원인:** .env 파일에 잘못된 사용자명 설정

**해결:**
```bash
# 현재 사용자명 확인
whoami

# .env 파일 수정
# DATABASE_URL=postgresql://실제사용자명@localhost:5432/stock_finder
```

#### 문제 3: `connection refused`

**해결:**
```bash
# PostgreSQL 서비스 상태 확인
brew services list | grep postgresql

# 서비스 시작
brew services start postgresql@16

# 서비스 재시작
brew services restart postgresql@16
```

#### 문제 4: `market_regime_daily does not exist`

**해결:**
```bash
cd ~/workspace/stock-finder/backend
python migrations/create_market_regime_daily.py
```

---

## 📊 과거 해결 사례 (work-logs 기준)

### 2024-11-23 해결된 문제

**문제:**
```bash
# 잘못된 설정
DATABASE_URL=postgresql://user:password@localhost:5432/stock_finder
```

**해결:**
```bash
# 올바른 설정
DATABASE_URL=postgresql://rexsmac@localhost:5432/stock_finder
```

**결과:**
- PostgreSQL 연결 성공
- `market_regime_daily` 테이블 생성 완료
- 21개 거래일 레짐 데이터 생성 완료

---

## 🔧 수동 DB 설정

### 1. PostgreSQL 접속 및 DB 생성

```bash
# PostgreSQL 접속
psql postgres

# 데이터베이스 생성
CREATE DATABASE stock_finder;

# 사용자 권한 확인
\du

# 데이터베이스 목록 확인
\l

# 종료
\q
```

### 2. 스키마 적용

```bash
cd ~/workspace/stock-finder/backend

# 기본 스키마 적용
psql -d stock_finder -f sql/postgres_schema.sql

# 검증 테이블 생성
psql -d stock_finder -f sql/create_market_analysis_validation.sql

# 레짐 테이블 생성
python migrations/create_market_regime_daily.py
```

### 3. 테이블 확인

```bash
# PostgreSQL 접속
psql -d stock_finder

# 테이블 목록 확인
\dt

# 예상 테이블:
# - users
# - scan_rank
# - market_conditions
# - market_analysis_validation
# - market_regime_daily
# - scanner_settings
# - portfolio
# - subscriptions
# - payments
# - email_verifications
# - news_data
# - search_trends
# - send_logs
# - positions
# - trading_history
# - maintenance_settings
# - popup_notice
# - daily_reports

# 종료
\q
```

---

## 🚨 긴급 복구 방법

### 완전 초기화

```bash
# 1. 기존 데이터베이스 삭제 (주의!)
psql postgres -c "DROP DATABASE IF EXISTS stock_finder;"

# 2. 새 데이터베이스 생성
psql postgres -c "CREATE DATABASE stock_finder;"

# 3. 스키마 재적용
cd ~/workspace/stock-finder/backend
psql -d stock_finder -f sql/postgres_schema.sql
psql -d stock_finder -f sql/create_market_analysis_validation.sql
python migrations/create_market_regime_daily.py

# 4. 연결 확인
python ~/workspace/stock-finder/check_db_connection.py
```

---

## 📝 환경별 설정

### macOS
```bash
# 사용자명 확인
whoami

# DATABASE_URL 설정
DATABASE_URL=postgresql://$(whoami)@localhost:5432/stock_finder
```

### Ubuntu
```bash
# postgres 사용자 사용
DATABASE_URL=postgresql://postgres@localhost:5432/stock_finder

# 또는 별도 사용자 생성
sudo -u postgres createuser --interactive your_username
DATABASE_URL=postgresql://your_username@localhost:5432/stock_finder
```

---

## 🔍 디버깅 명령어

### 연결 테스트
```bash
# 기본 연결
psql -d stock_finder -c "SELECT 1;"

# 버전 확인
psql -d stock_finder -c "SELECT version();"

# 테이블 개수 확인
psql -d stock_finder -c "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'public';"
```

### 로그 확인
```bash
# PostgreSQL 로그 (macOS)
tail -f /usr/local/var/log/postgresql@16.log

# 백엔드 로그
tail -f ~/workspace/stock-finder/backend/backend.log
```

---

## 📞 추가 지원

### 관련 파일
- `check_db_connection.py`: DB 연결 확인 스크립트
- `backend/config.py`: DB 설정 로드
- `backend/db.py`: DB 연결 관리
- `backend/migrations/`: 마이그레이션 스크립트

### 참고 문서
- `manuals/LOCAL_SETUP_MANUAL_20251109.md`: 전체 설정 가이드
- `docs/work-logs/WORK_SUMMARY_20241123.md`: 과거 DB 문제 해결 기록

---

**마지막 업데이트**: 2025년 11월 28일  
**기반 정보**: work-logs 문서 분석 결과