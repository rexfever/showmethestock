# Stock Finder 서버 배포 및 운영 매뉴얼 (2025-11-23 업데이트)

## 📋 목차
1. [시스템 아키텍처](#시스템-아키텍처)
2. [서버 환경 설정](#서버-환경-설정)
3. [배포 프로세스](#배포-프로세스)
4. [데이터베이스 관리](#데이터베이스-관리)
5. [레짐 분석 시스템](#레짐-분석-시스템)
6. [모니터링 및 운영](#모니터링-및-운영)
7. [트러블슈팅](#트러블슈팅)
8. [보안 및 백업](#보안-및-백업)

---

## 시스템 아키텍처

### 전체 구조
```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Frontend      │    │    Backend      │    │   Database      │
│   (Next.js)     │◄──►│   (FastAPI)     │◄──►│  (PostgreSQL)   │
│   Port: 3000    │    │   Port: 8010    │    │   Port: 5432    │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         │              ┌─────────────────┐              │
         │              │   Scheduler     │              │
         └──────────────┤   (15:31-15:42) ├──────────────┘
                        └─────────────────┘
                                 │
                        ┌─────────────────┐
                        │  External APIs  │
                        │ - Kiwoom API    │
                        │ - Yahoo Finance │
                        │ - Alpha Vantage │
                        └─────────────────┘
```

### 주요 컴포넌트
- **Frontend**: Next.js 기반 웹 인터페이스
- **Backend**: FastAPI 기반 REST API 서버
- **Database**: PostgreSQL 데이터 저장소
- **Scheduler**: 자동 스캔 및 분석 스케줄러
- **Cache System**: 미국 시장 데이터 캐시
- **Regime Analyzer**: 글로벌 레짐 분석 엔진

---

## 서버 환경 설정

### 시스템 요구사항
- **OS**: Ubuntu 22.04 LTS
- **RAM**: 최소 2GB (권장 4GB)
- **CPU**: 최소 2 vCPU
- **Storage**: 최소 50GB SSD
- **Network**: 안정적인 인터넷 연결

### 필수 소프트웨어 설치
```bash
# 시스템 업데이트
sudo apt update && sudo apt upgrade -y

# Python 3.10+ 설치
sudo apt install python3 python3-pip python3-venv -y

# Node.js 18+ 설치
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install nodejs -y

# PostgreSQL 설치
sudo apt install postgresql postgresql-contrib -y

# Nginx 설치 (선택사항)
sudo apt install nginx -y

# 기타 유틸리티
sudo apt install git curl wget htop -y
```

### 사용자 및 디렉토리 설정
```bash
# 프로젝트 디렉토리 생성
sudo mkdir -p /opt/stock-finder
sudo chown $USER:$USER /opt/stock-finder

# 로그 디렉토리 생성
sudo mkdir -p /var/log/stock-finder
sudo chown $USER:$USER /var/log/stock-finder

# 백업 디렉토리 생성
mkdir -p /opt/stock-finder/backups
```

---

## 배포 프로세스

### 1. 코드 배포
```bash
# 저장소 클론
cd /opt
git clone <repository-url> stock-finder
cd stock-finder

# 또는 기존 코드 업데이트
cd /opt/stock-finder
git pull origin main
```

### 2. 백엔드 배포
```bash
cd /opt/stock-finder/backend

# Python 가상환경 생성
python3 -m venv venv
source venv/bin/activate

# 의존성 설치
pip install -r requirements.txt

# 환경변수 설정
cp .env.example .env
nano .env  # 실제 값으로 수정

# 데이터베이스 마이그레이션
python migrations/create_market_regime_daily.py
python migrations/extend_market_conditions.py
```

### 3. 프론트엔드 배포
```bash
cd /opt/stock-finder/frontend

# 의존성 설치
npm install

# 환경변수 설정
cp .env.local.example .env.local
nano .env.local  # 실제 값으로 수정

# 프로덕션 빌드
npm run build
```

### 4. 서비스 등록
```bash
# 백엔드 서비스 파일 생성
sudo tee /etc/systemd/system/stock-finder-backend.service > /dev/null <<EOF
[Unit]
Description=Stock Finder Backend
After=network.target postgresql.service

[Service]
Type=simple
User=$USER
WorkingDirectory=/opt/stock-finder/backend
Environment="PATH=/opt/stock-finder/backend/venv/bin"
EnvironmentFile=/opt/stock-finder/backend/.env
ExecStart=/opt/stock-finder/backend/venv/bin/uvicorn main:app --host 0.0.0.0 --port 8010
Restart=always
RestartSec=10
StandardOutput=append:/var/log/stock-finder/backend.log
StandardError=append:/var/log/stock-finder/backend.log

[Install]
WantedBy=multi-user.target
EOF

# 프론트엔드 서비스 파일 생성
sudo tee /etc/systemd/system/stock-finder-frontend.service > /dev/null <<EOF
[Unit]
Description=Stock Finder Frontend
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=/opt/stock-finder/frontend
Environment="NODE_ENV=production"
ExecStart=/usr/bin/npm start
Restart=always
RestartSec=10
StandardOutput=append:/var/log/stock-finder/frontend.log
StandardError=append:/var/log/stock-finder/frontend.log

[Install]
WantedBy=multi-user.target
EOF

# 서비스 활성화 및 시작
sudo systemctl daemon-reload
sudo systemctl enable stock-finder-backend stock-finder-frontend
sudo systemctl start stock-finder-backend stock-finder-frontend
```

---

## 데이터베이스 관리

### PostgreSQL 설정
```bash
# PostgreSQL 사용자 생성
sudo -u postgres createuser --interactive stockfinder
sudo -u postgres createdb stockfinder -O stockfinder

# 비밀번호 설정
sudo -u postgres psql -c "ALTER USER stockfinder PASSWORD 'your_secure_password';"

# 권한 부여
sudo -u postgres psql -d stockfinder -c "GRANT ALL PRIVILEGES ON DATABASE stockfinder TO stockfinder;"
```

### 주요 테이블 구조
```sql
-- 사용자 테이블
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(100),
    provider VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 스캔 결과 테이블
CREATE TABLE scan_rank (
    id SERIAL PRIMARY KEY,
    date VARCHAR(8) NOT NULL,
    code VARCHAR(10) NOT NULL,
    name VARCHAR(100),
    score DECIMAL(5,2),
    scanner_version VARCHAR(10) DEFAULT 'v1'
);

-- 시장 상황 테이블
CREATE TABLE market_conditions (
    id SERIAL PRIMARY KEY,
    date VARCHAR(8) NOT NULL,
    kospi_return DECIMAL(8,4),
    market_sentiment VARCHAR(20),
    rsi_threshold DECIMAL(5,2),
    min_signals INTEGER
);

-- 레짐 분석 테이블
CREATE TABLE market_regime_daily (
    date VARCHAR(8) PRIMARY KEY,
    final_regime VARCHAR(20),
    final_score DECIMAL(8,4),
    kr_score DECIMAL(8,4),
    us_prev_score DECIMAL(8,4),
    version VARCHAR(20) DEFAULT 'regime_v4'
);
```

### 데이터베이스 백업
```bash
# 자동 백업 스크립트 생성
cat > /opt/stock-finder/scripts/backup_db.sh << 'EOF'
#!/bin/bash
BACKUP_DIR="/opt/stock-finder/backups"
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="$BACKUP_DIR/stockfinder_$DATE.sql.gz"

mkdir -p $BACKUP_DIR
pg_dump -U stockfinder -h localhost stockfinder | gzip > $BACKUP_FILE

# 7일 이상 된 백업 삭제
find $BACKUP_DIR -name "stockfinder_*.sql.gz" -mtime +7 -delete

echo "Backup completed: $BACKUP_FILE"
EOF

chmod +x /opt/stock-finder/scripts/backup_db.sh

# Cron 설정 (매일 새벽 2시)
echo "0 2 * * * /opt/stock-finder/scripts/backup_db.sh" | crontab -
```

---

## 레짐 분석 시스템

### Global Regime v4 아키텍처
```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   한국 시장     │    │   미국 시장     │    │   미국 선물     │
│   (KOSPI)       │    │  (SPY, QQQ)     │    │ (ES=F, NQ=F)    │
│   가중치: 60%   │    │   가중치: 20%   │    │   가중치: 20%   │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         └───────────────────────┼───────────────────────┘
                                 │
                    ┌─────────────────┐
                    │  Global Regime  │
                    │   Analyzer v4   │
                    └─────────────────┘
                                 │
                    ┌─────────────────┐
                    │ Final Regime    │
                    │ bull/neutral/   │
                    │ bear/crash      │
                    └─────────────────┘
```

### 레짐별 스캐너 설정
```python
REGIME_SETTINGS = {
    'bull': {
        'rsi_threshold': 65.0,
        'min_signals': 2,
        'description': '완화된 조건으로 상승 추세 포착'
    },
    'neutral': {
        'rsi_threshold': 58.0,
        'min_signals': 3,
        'description': '기본 조건'
    },
    'bear': {
        'rsi_threshold': 45.0,
        'min_signals': 4,
        'description': '엄격한 조건으로 리스크 관리'
    },
    'crash': {
        'rsi_threshold': 40.0,
        'min_signals': 999,
        'description': '추천 중단 - 안전 우선'
    }
}
```

### 캐시 시스템 관리
```bash
# 캐시 디렉토리 구조
/opt/stock-finder/cache/
├── regime/              # 레짐 분석 결과 캐시
├── us_futures/          # 미국 선물 데이터 캐시
└── market_data/         # 시장 데이터 캐시

# 캐시 정리 스크립트
cat > /opt/stock-finder/scripts/clean_cache.sh << 'EOF'
#!/bin/bash
CACHE_DIR="/opt/stock-finder/cache"

# 7일 이상 된 캐시 파일 삭제
find $CACHE_DIR -type f -mtime +7 -delete

# 빈 디렉토리 삭제
find $CACHE_DIR -type d -empty -delete

echo "Cache cleanup completed"
EOF

chmod +x /opt/stock-finder/scripts/clean_cache.sh
```

---

## 모니터링 및 운영

### 자동 스케줄러 모니터링
```bash
# 스케줄러 동작 확인
sudo journalctl -u stock-finder-backend | grep "스케줄러"

# 장세 분석 결과 확인
psql -U stockfinder -d stockfinder -c "
SELECT date, final_regime, final_score 
FROM market_regime_daily 
ORDER BY date DESC 
LIMIT 10;"

# 스캔 결과 확인
psql -U stockfinder -d stockfinder -c "
SELECT date, COUNT(*) as stock_count 
FROM scan_rank 
WHERE date >= '20251101' 
GROUP BY date 
ORDER BY date DESC;"
```

### 시스템 상태 모니터링
```bash
# 종합 상태 확인 스크립트
cat > /opt/stock-finder/scripts/system_status.sh << 'EOF'
#!/bin/bash

echo "=== Stock Finder System Status ==="
echo "Date: $(date)"
echo ""

# 서비스 상태
echo "Services:"
systemctl is-active stock-finder-backend && echo "✅ Backend: Running" || echo "❌ Backend: Stopped"
systemctl is-active stock-finder-frontend && echo "✅ Frontend: Running" || echo "❌ Frontend: Stopped"
systemctl is-active postgresql && echo "✅ PostgreSQL: Running" || echo "❌ PostgreSQL: Stopped"
echo ""

# API 응답 확인
echo "API Health:"
curl -s http://localhost:8010/health > /dev/null && echo "✅ Backend API: OK" || echo "❌ Backend API: Failed"
curl -s http://localhost:3000 > /dev/null && echo "✅ Frontend: OK" || echo "❌ Frontend: Failed"
echo ""

# 리소스 사용량
echo "Resources:"
echo "CPU: $(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | cut -d'%' -f1)%"
echo "Memory: $(free | grep Mem | awk '{printf "%.1f%%", $3/$2 * 100.0}')"
echo "Disk: $(df -h / | awk 'NR==2{print $5}')"
echo ""

# 최근 스캔 데이터
echo "Recent Scans:"
psql -U stockfinder -d stockfinder -t -c "
SELECT date || ': ' || COUNT(*) || ' stocks' 
FROM scan_rank 
WHERE date >= '$(date -d '7 days ago' +%Y%m%d)' 
GROUP BY date 
ORDER BY date DESC 
LIMIT 5;" 2>/dev/null || echo "Database connection failed"

echo "=================================="
EOF

chmod +x /opt/stock-finder/scripts/system_status.sh
```

### 로그 관리
```bash
# 로그 로테이션 설정
sudo tee /etc/logrotate.d/stock-finder > /dev/null <<EOF
/var/log/stock-finder/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 644 $USER $USER
    postrotate
        systemctl reload stock-finder-backend stock-finder-frontend
    endscript
}
EOF
```

---

## 트러블슈팅

### 일반적인 문제 해결

#### 1. 백엔드 서비스 시작 실패
```bash
# 로그 확인
sudo journalctl -u stock-finder-backend -n 50

# 수동 실행으로 에러 확인
cd /opt/stock-finder/backend
source venv/bin/activate
python main.py

# 포트 충돌 확인
sudo lsof -i :8010
```

#### 2. 데이터베이스 연결 오류
```bash
# PostgreSQL 상태 확인
sudo systemctl status postgresql

# 연결 테스트
psql -U stockfinder -d stockfinder -c "SELECT version();"

# 환경변수 확인
grep DATABASE_URL /opt/stock-finder/backend/.env
```

#### 3. 레짐 분석 오류
```bash
# 캐시 클리어
rm -rf /opt/stock-finder/cache/regime/*

# 미국 데이터 캐시 확인
ls -la /opt/stock-finder/cache/us_futures/

# 레짐 분석 수동 실행
cd /opt/stock-finder/backend
python -c "
from services.regime_analyzer_cached import regime_analyzer_cached
result = regime_analyzer_cached.analyze_regime_v4_cached('$(date +%Y%m%d)')
print(f'Result: {result.get(\"final_regime\")} ({result.get(\"final_score\")})')
"
```

#### 4. 스케줄러 동작 안 함
```bash
# 스케줄러 로그 확인
sudo journalctl -u stock-finder-backend | grep -E "스케줄러|scheduler"

# 거래일 확인
cd /opt/stock-finder/backend
python -c "
from main import is_trading_day
from datetime import datetime
today = datetime.now().strftime('%Y%m%d')
print(f'Today ({today}) is trading day: {is_trading_day(today)}')
"

# 시간대 확인
timedatectl status
```

### 성능 최적화

#### PostgreSQL 튜닝
```bash
# postgresql.conf 편집
sudo nano /etc/postgresql/*/main/postgresql.conf

# 권장 설정 (4GB RAM 기준)
# shared_buffers = 1GB
# work_mem = 16MB
# maintenance_work_mem = 256MB
# effective_cache_size = 3GB
# max_connections = 100

# 설정 적용
sudo systemctl restart postgresql
```

#### 캐시 최적화
```bash
# 캐시 사용량 모니터링
du -sh /opt/stock-finder/cache/*

# 캐시 히트율 확인
cd /opt/stock-finder/backend
python -c "
from services.regime_data_cache import regime_cache
stats = regime_cache.get_cache_stats()
print(f'Cache stats: {stats}')
"
```

---

## 보안 및 백업

### 보안 설정
```bash
# 방화벽 설정
sudo ufw enable
sudo ufw allow ssh
sudo ufw allow 80
sudo ufw allow 443
sudo ufw allow 8010  # 백엔드 (필요시)
sudo ufw allow 3000  # 프론트엔드 (필요시)

# SSL 인증서 설정 (Let's Encrypt)
sudo apt install certbot python3-certbot-nginx -y
sudo certbot --nginx -d your-domain.com

# 환경변수 파일 권한 설정
chmod 600 /opt/stock-finder/backend/.env
chmod 600 /opt/stock-finder/frontend/.env.local
```

### 백업 전략
```bash
# 전체 백업 스크립트
cat > /opt/stock-finder/scripts/full_backup.sh << 'EOF'
#!/bin/bash

BACKUP_DIR="/opt/stock-finder/backups/$(date +%Y%m%d)"
mkdir -p $BACKUP_DIR

# 데이터베이스 백업
pg_dump -U stockfinder stockfinder | gzip > $BACKUP_DIR/database.sql.gz

# 설정 파일 백업
cp /opt/stock-finder/backend/.env $BACKUP_DIR/
cp /opt/stock-finder/frontend/.env.local $BACKUP_DIR/

# 캐시 백업 (선택사항)
tar -czf $BACKUP_DIR/cache.tar.gz -C /opt/stock-finder cache/

# S3 업로드 (AWS CLI 설정 필요)
# aws s3 sync $BACKUP_DIR s3://your-backup-bucket/$(date +%Y%m%d)/

echo "Full backup completed: $BACKUP_DIR"
EOF

chmod +x /opt/stock-finder/scripts/full_backup.sh

# 주간 백업 Cron 설정
echo "0 3 * * 0 /opt/stock-finder/scripts/full_backup.sh" | crontab -
```

### 재해 복구 계획
```bash
# 복구 스크립트 템플릿
cat > /opt/stock-finder/scripts/disaster_recovery.sh << 'EOF'
#!/bin/bash

BACKUP_DATE=$1
if [ -z "$BACKUP_DATE" ]; then
    echo "Usage: $0 YYYYMMDD"
    exit 1
fi

BACKUP_DIR="/opt/stock-finder/backups/$BACKUP_DATE"

if [ ! -d "$BACKUP_DIR" ]; then
    echo "Backup directory not found: $BACKUP_DIR"
    exit 1
fi

echo "Starting disaster recovery from $BACKUP_DATE..."

# 서비스 중지
sudo systemctl stop stock-finder-backend stock-finder-frontend

# 데이터베이스 복구
sudo -u postgres dropdb stockfinder
sudo -u postgres createdb stockfinder -O stockfinder
gunzip < $BACKUP_DIR/database.sql.gz | psql -U stockfinder stockfinder

# 설정 파일 복구
cp $BACKUP_DIR/.env /opt/stock-finder/backend/
cp $BACKUP_DIR/.env.local /opt/stock-finder/frontend/

# 캐시 복구 (선택사항)
if [ -f "$BACKUP_DIR/cache.tar.gz" ]; then
    tar -xzf $BACKUP_DIR/cache.tar.gz -C /opt/stock-finder/
fi

# 서비스 시작
sudo systemctl start stock-finder-backend stock-finder-frontend

echo "Disaster recovery completed"
EOF

chmod +x /opt/stock-finder/scripts/disaster_recovery.sh
```

---

## 운영 체크리스트

### 일일 점검
- [ ] 서비스 상태 확인 (`systemctl status`)
- [ ] API 응답 확인 (`curl health check`)
- [ ] 스캔 데이터 생성 확인
- [ ] 에러 로그 확인
- [ ] 디스크 사용량 확인

### 주간 점검
- [ ] 백업 파일 확인
- [ ] 캐시 정리 실행
- [ ] 성능 메트릭 리뷰
- [ ] 보안 업데이트 확인

### 월간 점검
- [ ] 전체 백업 실행
- [ ] 데이터베이스 최적화 (VACUUM)
- [ ] 로그 파일 정리
- [ ] 시스템 업데이트 적용
- [ ] 재해 복구 테스트

---

## 연락처 및 지원

### 긴급 상황 대응
1. 서비스 상태 확인: `/opt/stock-finder/scripts/system_status.sh`
2. 로그 확인: `sudo journalctl -u stock-finder-backend -f`
3. 서비스 재시작: `sudo systemctl restart stock-finder-*`
4. 백업에서 복구: `/opt/stock-finder/scripts/disaster_recovery.sh`

### 문서 및 리소스
- **개발 환경 설정**: `DEVELOPMENT_SETUP_MANUAL.md`
- **API 문서**: `http://localhost:8010/docs`
- **GitHub Repository**: [프로젝트 저장소]

---

**문서 버전**: 2.0  
**최종 업데이트**: 2025-11-23  
**작성자**: Development Team  
**검토자**: Operations Team