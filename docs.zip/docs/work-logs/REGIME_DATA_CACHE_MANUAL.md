# 레짐 분석 데이터 캐시 관리 메뉴얼

## 📋 기본 원칙

### 🔄 데이터 사용 원칙
1. **레짐 분석은 항상 캐시된 데이터를 사용한다**
2. **캐시 데이터는 1일 단위로 최신 데이터를 추가한다**
3. **실시간 API 호출은 금지 - 성능과 안정성을 위해 캐시만 사용**

## 📊 캐시 데이터 구조

### 🇰🇷 한국 시장 데이터
```
backend/data_cache/
├── kospi200_ohlcv.pkl          # KOSPI200 지수 (2020-01-01~현재)
├── spy_ohlcv.pkl               # SPY ETF (2020-01-01~현재)
├── qqq_ohlcv.pkl               # QQQ ETF (2020-01-01~현재)
├── vix_ohlcv.pkl               # VIX 지수 (2020-01-01~현재)
├── universe_ohlcv.pkl          # 유니버스 종목 통합
├── ohlcv/                      # 개별 종목 OHLCV (500+ 파일)
└── indicators/                 # 개별 종목 기술지표 (200+ 파일)
```

### 🇺🇸 미국 시장 데이터
```
cache/us_futures/
├── SPY.csv                     # S&P 500 ETF (2023-11-22~현재)
├── QQQ.csv                     # NASDAQ 100 ETF (2023-11-22~현재)
├── ^VIX.csv                    # 변동성 지수 (2023-11-21~현재)
├── ES_F.csv                    # S&P 500 선물
├── NQ_F.csv                    # NASDAQ 선물
└── DX_Y_NYB.csv               # 달러 지수
```

## 🔧 데이터 업데이트 프로세스

### 일일 업데이트 절차
1. **매일 장 마감 후 (16:00 이후) 실행**
2. **전일 데이터만 추가 (incremental update)**
3. **기존 데이터는 보존, 새 데이터만 append**

### 업데이트 스크립트 위치
```bash
# 한국 데이터 업데이트
backend/daily_update_service.py

# 미국 데이터 업데이트  
backend/services/us_futures_data.py

# 자동 업데이트 크론잡
scripts/setup-daily-update-cron.sh
```

## 📈 레짐 분석 데이터 접근

### Global Regime v3
```python
# 한국 데이터 (항상 캐시 사용)
kospi_return, volatility, kospi_low_return = self._get_kospi_data(date)

# 미국 데이터 (항상 캐시 사용)
us_prev_snapshot = get_us_prev_snapshot(date)
```

### Global Regime v4
```python
# 캐시 직접 접근 (최대 속도)
data = load_full_data(date)
kr_df = data["KR"]      # kospi200_ohlcv.pkl
spy_df = data["SPY"]    # cache/us_futures/SPY.csv
qqq_df = data["QQQ"]    # cache/us_futures/QQQ.csv
vix_df = data["VIX"]    # cache/us_futures/^VIX.csv
```

## ⚠️ 중요 규칙

### 🚫 금지사항
- **실시간 API 호출 금지** (yfinance, Kiwoom API 등)
- **대량 데이터 재다운로드 금지**
- **캐시 우회 접근 금지**

### ✅ 허용사항
- **캐시 데이터 읽기만 허용**
- **일일 incremental 업데이트만 허용**
- **데이터 검증 및 정합성 체크**

## 🔍 데이터 검증

### 일일 검증 항목
1. **데이터 연속성**: 날짜 gap 없는지 확인
2. **데이터 품질**: 이상값, null 값 체크
3. **최신성**: 전일 데이터까지 업데이트 확인

### 검증 스크립트
```bash
# 데이터 검증 실행
python3 scripts/regime_v3/maintenance/validate_data.py

# 데이터 정리 (필요시)
python3 scripts/regime_v3/maintenance/cleanup_old_data.py
```

## 📊 성능 최적화

### 캐시 활용 전략
- **메모리 캐싱**: 자주 사용하는 데이터는 메모리에 보관
- **파일 캐싱**: 대용량 데이터는 pickle/CSV로 저장
- **압축 저장**: 용량 절약을 위한 압축 적용

### 접근 속도
- **v3 분석**: < 1초 (네트워크 없음)
- **v4 분석**: < 0.5초 (직접 캐시 접근)
- **백테스트**: 빠른 대량 처리 가능

## 🛠️ 트러블슈팅

### 캐시 데이터 문제 시
```bash
# 캐시 상태 확인
ls -la backend/data_cache/
ls -la cache/us_futures/

# 데이터 기간 확인
python3 -c "
import pandas as pd, pickle
with open('backend/data_cache/kospi200_ohlcv.pkl', 'rb') as f:
    df = pickle.load(f)
print(f'KOSPI200: {df.index.min()} ~ {df.index.max()}')"

# 캐시 재생성 (최후 수단)
python3 backend/create_cache_data.py
```

### 데이터 누락 시
1. **일일 업데이트 스크립트 실행**
2. **크론잡 상태 확인**
3. **수동 데이터 보완**

## 📝 운영 체크리스트

### 일일 점검 (자동화)
- [ ] 전일 데이터 업데이트 완료
- [ ] 캐시 파일 크기 정상
- [ ] 데이터 연속성 확인
- [ ] 레짐 분석 정상 동작

### 주간 점검 (수동)
- [ ] 캐시 용량 관리
- [ ] 데이터 품질 검증
- [ ] 성능 모니터링
- [ ] 백업 상태 확인

---

## 🎯 핵심 메시지

**"레짐 분석은 항상 캐시된 데이터를 사용하며, 1일 단위로 최신 데이터를 추가한다"**

이 원칙을 준수하여 안정적이고 빠른 레짐 분석 시스템을 유지합니다.

---

*작성일: 2025년 11월 23일*  
*작성자: Amazon Q Developer*  
*버전: v1.0*