# 시스템 상태 보고서 - 2025년 11월 23일

## 📅 스케줄러 동작 현황

### 자동 실행 시간 (KST 기준)
- **15:31~15:40**: 데이터 검증 (매분 실행)
- **15:40**: 장세 분석 실행
- **15:42**: 스캔 실행 및 알림 발송

### 실행 순서
1. **데이터 검증** (`run_validation`) - 장세 데이터 확정 여부 확인
2. **장세 분석** (`run_market_analysis`) - 시장 상황 분석 후 DB 저장
3. **스캔 실행** (`run_scan`) - 장세 분석 결과 기반 스캔
4. **자동 알림** (`send_auto_notification`) - 솔라피 알림톡 발송

### 거래일 체크
- 주말과 공휴일 자동 제외
- 한국 공휴일 체크 포함

## 🔄 Fallback 시스템 현황

### 하이브리드 Fallback 로직
- **신호 충족** = 후보군 (점수 무관)
- **점수** = 순위 매기기용

### Fallback 단계
- **Step 0**: 기본 조건 (신호 충족 종목만)
- **Step 1**: 지표 완화 Level 1 + 신호 충족
- **Step 2**: 지표 완화 Level 1 (신호 충족 종목만)
- **Step 3**: 지표 완화 Level 2 + 8점 이상

### 장세별 목표 개수
- **강세장/중립장**: `fallback_target_min_bull` ~ `fallback_target_max_bull`개
- **약세장**: `fallback_target_min_bear` ~ `fallback_target_max_bear`개
- **급락장 (crash)**: 추천 종목 없음 반환

## 🔧 스캐너 버전 현황

### 현재 실행 버전
**v1 스캐너** 실행 중

### 버전 결정 우선순위
1. **DB 설정** (`scanner_settings` 테이블)
2. **.env 파일** (`SCANNER_VERSION`)
3. **기본값** (`v1`)

### 현재 설정 상태
- **DB**: `scanner_version = "v1"`, `scanner_v2_enabled = false`
- **.env**: `SCANNER_VERSION` 설정 없음
- **결과**: v1 스캐너 사용

### 버전 변경 방법
```bash
# 관리자 API
POST /admin/scanner-settings
{
  "scanner_version": "v2",
  "scanner_v2_enabled": true
}
```

## 🗄️ 데이터베이스 구조

### 주요 테이블
- `scan_rank`: 스캔 결과 저장 (버전별 구분)
- `market_conditions`: 장세 분석 결과
- `market_analysis_validation`: 데이터 검증 결과
- `scanner_settings`: 스캐너 설정 관리

### 버전별 데이터 구분
```sql
PRIMARY KEY (date, code, scanner_version)
```

## 🚨 긴급 상황 대응

### 급락장 감지
- Global Regime v3/v4에서 'crash' 감지 시 빈 리스트 반환
- KOSPI 급락 시 추천 종목 없음

### 데이터 검증
- 15:31~15:40 매분 데이터 확정 여부 검증
- `market_analysis_validation` 테이블에 결과 저장

## 📊 시장 분석 시스템

### 장세 분석 버전
- **v4**: Global Regime v4 (우선 시도)
- **v3**: Global Regime v3 (v4 실패 시 fallback)
- **v1**: 기본 분석 (v3 실패 시 fallback)

### 장세별 RSI 임계값
- **강세장**: 65.0
- **중립장**: 58.0
- **약세장**: 45.0

## 🔍 현재 시스템 상태 요약

- ✅ 스케줄러 정상 동작 (15:31~15:42 자동 실행)
- ✅ v1 스캐너 실행 중
- ✅ 하이브리드 Fallback 시스템 활성화
- ✅ 장세별 적응형 스캔 조건 적용
- ✅ 급락장 감지 시 안전 장치 작동
- ✅ 데이터 검증 시스템 운영 중

---
**작성일**: 2025년 11월 23일  
**작성자**: AI Assistant  
**문서 버전**: 1.0