# Global Regime Model v3 통합 작업 계획서

## 📋 프로젝트 개요

### 🎯 **목표**
기존 backend/ 구조를 기반으로 Global Regime Model v3를 통합하여 한국/미국 시장 데이터를 결합한 고도화된 장세 분석 시스템 구축

### 🔧 **접근 방식**
- **Option A**: 기존 `market_analyzer.py` 확장/대체
- **호환성 우선**: 기존 코드 깨지지 않게 확장
- **점진적 통합**: V1/V2 스캐너와 단계적 연동

---

## 📅 실행 계획

### **Phase 1: 인프라 구축** ✅ **COMPLETED (2025-11-22)**
- [x] DB 마이그레이션: `market_regime_daily` 테이블 생성
- [x] Regime Storage 서비스: 장세 데이터 저장/로드 
- [x] US Market Data 헬퍼: yfinance 기반 미국 시장 데이터

**Phase 1 완료 결과:**
- `create_market_regime_daily.py`: PostgreSQL 테이블 생성 마이그레이션
- `services/regime_storage.py`: save/load/upsert 함수 구현
- `services/us_market_data.py`: SPY/QQQ/VIX/TNX 데이터 로딩

### **Phase 2: Core Engine 구현** ✅ **COMPLETED (2025-11-22)**
- [x] MarketCondition dataclass 확장 (v3 필드 추가)
- [x] 한국 장세 점수 계산 함수 (`compute_kr_regime_score_v3`)
- [x] 미국 전일 장세 점수 함수 (`compute_us_prev_score`)
- [x] 미국 pre-open 리스크 함수 (`compute_us_preopen_risk`)
- [x] 글로벌 레짐 조합 함수 (`compose_global_regime_v3`)
- [x] 메인 분석 함수 (`analyze_market_condition_v3`)

**Phase 2 완료 결과:**
- MarketCondition에 v3 필드 추가: `final_regime`, `final_score`, `kr_score` 등
- 한국 장세 4개 점수 조합: trend/vol/breadth/intraday (-2~+2 범위)
- 미국 장세 3개 점수 조합: trend/vol/macro
- 글로벌 조합: 한국 60% + 미국 40% + pre-open 리스크 페널티
- DB 자동 저장: upsert_regime으로 결과 저장

### **Phase 3: Scanner 연동** ✅ **COMPLETED (2025-11-22)**
- [x] `services/scan_service.py` v3 연동
- [x] `scanner_v2` horizon cutoff 조정
- [x] 장세별 candidate 필터링 로직

**Phase 3 완료 결과:**
- scan_service.py: analyze_market_condition_v3 자동 호출 및 v3 장세 우선 사용
- crash 감지: v3 final_regime='crash' 시 추천 종목 없음 반환
- 장세별 목표: v3 final_regime 기준으로 bear/bull 구분하여 fallback 설정
- scanner_v2: 장세별 horizon cutoff 적용 (bull/neutral/bear/crash 각각 다른 점수 기준)
- 통합 필터링: swing/position/longterm 별 max candidates 적용

### **Phase 4: Backtest 유틸** ✅ **COMPLETED (2025-11-22)**
- [x] `scanner_v2/regime_backtest_v3.py` 구현
- [x] 레짐별 성과 분석 함수

**Phase 4 완료 결과:**
- run_regime_backtest(): 기간별 레짐 분포 및 KOSPI 수익률 분석
- analyze_regime_transitions(): 레짐 전환 패턴 분석
- 자동 DB 연동: 없는 날짜는 v3 분석 후 저장, 있는 날짜는 로드
- 통계 출력: 레짐별 평균수익률, 승률, 누적수익률, 분포 등

---

## 🔧 구체적 수정 파일

### **Phase 1 완료 파일** ✅
```
backend/migrations/create_market_regime_daily.py  # 신규 생성
backend/services/regime_storage.py               # 신규 생성
backend/services/us_market_data.py               # 신규 생성
```

### **Phase 2 완료 파일** ✅
```
backend/market_analyzer.py                       # MarketCondition 확장, v3 함수들 추가
```

### **Phase 3 수정 대상** 🔄
```
backend/services/scan_service.py                 # v3 장세 분석 연동
backend/scanner_v2/core/scanner.py               # horizon cutoff 조정
```

### **Phase 4 수정 대상** 📋
```
backend/scanner_v2/regime_backtest_v3.py         # 신규 생성
```

---

## ✅ 검증 기준

### **Phase 1 완료 조건** ✅ **COMPLETED (2025-11-22)**
- [x] `market_regime_daily` 테이블 생성 마이그레이션 작동
- [x] regime_storage 모듈의 save/load/upsert 함수 구현
- [x] us_market_data 모듈의 yfinance 연동 구현
- [x] 모든 모듈 import 오류 없음

### **Phase 2 완료 조건** ✅ **COMPLETED (2025-11-22)**
- [x] `analyze_market_condition_v3()` 함수 정상 동작
- [x] 한국/미국 장세 점수 계산 검증
- [x] DB 저장/로드 테스트 통과
- [x] 기존 `analyze_market_condition()` 호환성 유지

**Phase 2 완료 결과:**
- MarketCondition 확장: 9개 v3 필드 추가 (final_regime, final_score 등)
- 한국 장세 분석: 4개 점수 조합으로 bull/neutral/bear/crash 구분
- 미국 장세 분석: SPY/QQQ 추세, VIX 변동성, 10Y 금리 조합
- 글로벌 조합: 가중평균 + 리스크 페널티로 최종 레짐 결정
- DB 연동: analyze_market_condition_v3 실행 시 자동 저장
- 호환성 유지: 기존 v1 함수 그대로 유지, v3는 추가 확장

### **Phase 3 완료 조건** ✅ **COMPLETED (2025-11-22)**
- [x] V2 스캐너에서 v3 장세 사용
- [x] 장세별 horizon cutoff 적용 확인
- [x] 스캔 결과에 final_regime 포함

**Phase 3 완료 결과:**
- scan_service.py: market_condition 없으면 자동으로 v3 분석 실행
- v3 우선 사용: final_regime 기준으로 crash 감지 및 목표 개수 설정
- scanner_v2 cutoff: bull(6.0/4.3/5.0), neutral(6.0/4.5/6.0), bear(999/5.5/6.0), crash(999/999/999)
- horizon 필터링: swing/position/longterm 별 점수 기준 적용 및 max candidates 제한

### **Phase 4 완료 조건** ✅ **COMPLETED (2025-11-22)**
- [x] 레짐 백테스트 실행 가능
- [x] 장세별 통계 출력 정상

**Phase 4 완료 결과:**
- run_regime_backtest(): 기간 지정하여 레짐별 KOSPI 수익률 분석 가능
- analyze_regime_transitions(): 레짐 전환 패턴 및 확률 분석
- 자동 데이터 처리: DB에 없는 날짜는 v3 분석 후 저장
- 상세 통계: 레짐별 일수, 평균/표준편차/누적 수익률, 승률 등

---

## 🚨 리스크 관리

### **High Risk**
- **기존 API 호환성**: `analyze_market_condition()` 유지 필수 ✅ **해결됨**
- **yfinance 의존성**: 미국 데이터 fetch 실패 시 fallback ✅ **구현됨**

### **Medium Risk**
- **성능 영향**: 추가 계산 로직으로 인한 지연
- **데이터 품질**: 미국 시장 휴장일 처리

### **Mitigation Plan**
1. **호환성 보장**: 기존 함수 그대로 유지 ✅
2. **Fallback 로직**: 데이터 실패 시 기본값 사용 ✅
3. **캐싱 전략**: 계산 결과 DB 저장으로 재사용 ✅

---

## 📊 성공 지표

### **기술적 지표**
- v3 장세 분석 정확도: 95% 이상
- API 응답 시간: 기존 대비 +20% 이내
- 데이터 fetch 성공률: 90% 이상

### **비즈니스 지표**
- 장세 구분 정확도: bull/neutral/bear/crash 명확 구분
- 스캐너 성과 개선: 장세별 최적화된 후보 선별
- 백테스트 활용도: 레짐별 성과 분석 가능

---

*작업 계획서 작성일: 2025-11-22*  
*최종 수정일: 2025-11-22*  
*담당자: Amazon Q Developer*