# 기술 사양서 - Global Regime Model v3

## 🏗️ **시스템 아키텍처**

### **전체 구조**
```
Global Regime Model v3
├── Data Layer
│   ├── US Market Data (yfinance)
│   ├── KR Market Data (기존 API)
│   └── Database (PostgreSQL)
├── Analysis Engine
│   ├── KR Regime Scorer
│   ├── US Regime Scorer
│   ├── Global Composer
│   └── Risk Calculator
├── Integration Layer
│   ├── Scanner v2 Integration
│   ├── Fallback Logic
│   └── Configuration Management
└── Tools & Utilities
    ├── Backtest Engine
    ├── Operational Scripts
    └── Monitoring Tools
```

---

## 📊 **데이터 모델**

### **market_regime_daily 테이블**
```sql
CREATE TABLE market_regime_daily (
    date DATE PRIMARY KEY,                           -- 날짜 (YYYY-MM-DD)
    us_prev_sentiment VARCHAR(20) DEFAULT 'neutral', -- 미국 전일 레짐
    kr_sentiment VARCHAR(20) DEFAULT 'neutral',      -- 한국 레짐
    us_preopen_sentiment VARCHAR(20) DEFAULT 'none', -- 미국 pre-open 상태
    final_regime VARCHAR(20) DEFAULT 'neutral',      -- 최종 글로벌 레짐
    us_metrics JSONB,                                -- 미국 지표 상세
    kr_metrics JSONB,                                -- 한국 지표 상세
    us_preopen_metrics JSONB,                        -- pre-open 지표 상세
    run_timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    version VARCHAR(20) DEFAULT 'regime_v3'
);
```

### **MarketCondition 확장**
```python
@dataclass
class MarketCondition:
    # 기존 v1 필드들...
    
    # Global Regime v3 필드들
    final_regime: str = ""           # bull/neutral/bear/crash
    final_score: float = 0.0         # 최종 점수
    kr_score: float = 0.0            # 한국 점수
    us_prev_score: float = 0.0       # 미국 점수
    us_preopen_risk_score: float = 0.0  # pre-open 리스크
    kr_regime: str = ""              # 한국 레짐
    us_prev_regime: str = ""         # 미국 레짐
    us_preopen_flag: str = ""        # pre-open 플래그
    intraday_drop: float = 0.0       # 장중 하락률
    version: str = "regime_v1"       # 버전 정보
```

---

## 🧮 **핵심 알고리즘**

### **1. 한국 장세 점수 계산**
```python
def compute_kr_regime_score_v3(date: str) -> Dict[str, Any]:
    # 4개 점수 조합
    kr_trend_score = calculate_trend_score()      # -2 ~ +2
    kr_vol_score = calculate_volatility_score()  # -1 ~ +1  
    kr_breadth_score = calculate_breadth_score()  # -1 ~ +1
    kr_intraday_score = calculate_intraday_score() # -1 ~ +1
    
    kr_score = kr_trend_score + kr_vol_score + kr_breadth_score + kr_intraday_score
    
    # 레짐 분류
    if intraday_drop <= -0.025 and kospi_return < -0.02:
        kr_regime = "crash"
    elif kr_score >= 2:
        kr_regime = "bull"
    elif kr_score <= -2:
        kr_regime = "bear"
    else:
        kr_regime = "neutral"
```

### **2. 미국 장세 점수 계산**
```python
def compute_us_prev_score(snapshot: Dict[str, Any]) -> Dict[str, Any]:
    # 3개 점수 조합
    trend_score = calculate_us_trend(spy_r3, qqq_r3, spy_r5, qqq_r5)
    vol_score = calculate_us_volatility(vix, vix_change)
    macro_score = calculate_us_macro(ust10y_change)
    
    us_prev_score = trend_score + vol_score + macro_score
    
    # 레짐 분류 (VIX 우선 규칙)
    if vix > 35:
        us_prev_regime = "crash"
    elif us_prev_score >= 2:
        us_prev_regime = "bull"
    elif us_prev_score <= -2:
        us_prev_regime = "bear"
    else:
        us_prev_regime = "neutral"
```

### **3. 글로벌 레짐 조합**
```python
def compose_global_regime_v3(kr, us_prev, us_preopen, mode="backtest"):
    # 가중 평균 계산
    base_score = 0.6 * kr["kr_score"] + 0.4 * us_prev["us_prev_score"]
    
    # pre-open 리스크 페널티
    risk_penalty = 0.0
    if us_preopen["us_preopen_flag"] == "watch":
        risk_penalty += 0.5
    elif us_preopen["us_preopen_flag"] == "danger":
        risk_penalty += 1.0
    
    final_score = base_score - risk_penalty
    
    # Crash 우선 규칙
    if us_prev["us_prev_regime"] == "crash" or kr["kr_regime"] == "crash":
        final_regime = "crash"
    elif mode == "live" and us_preopen["us_preopen_flag"] == "danger":
        final_regime = "crash"
    elif final_score >= 2.0:
        final_regime = "bull"
    elif final_score <= -2.0:
        final_regime = "bear"
    else:
        final_regime = "neutral"
```

---

## 🎯 **스캐너 연동 로직**

### **장세별 Horizon Cutoff**
```python
REGIME_CUTOFFS = {
    'bull': {
        'swing': 6.0,      # 강세장: 적극적 단기 매매
        'position': 4.3,   # 중기 포지션 완화
        'longterm': 5.0    # 장기 투자 활성화
    },
    'neutral': {
        'swing': 6.0,      # 중립장: 균형잡힌 접근
        'position': 4.5,   
        'longterm': 6.0
    },
    'bear': {
        'swing': 999.0,    # 약세장: 단기 매매 비활성화
        'position': 5.5,   # 보수적 중기 포지션
        'longterm': 6.0    # 장기는 유지
    },
    'crash': {
        'swing': 999.0,    # 급락장: 모든 매매 중단
        'position': 999.0,
        'longterm': 999.0
    }
}
```

### **Max Candidates 제한**
```python
MAX_CANDIDATES = {
    'swing': 20,     # 단기 매매 최대 20개
    'position': 15,  # 중기 포지션 최대 15개
    'longterm': 20   # 장기 투자 최대 20개
}
```

---

## 🔄 **데이터 플로우**

### **실시간 분석 플로우**
```
1. 한국 시장 데이터 수집 (기존 API)
   ├── KOSPI200 OHLCV
   ├── 유니버스 평균 수익률
   └── 거래량 데이터

2. 미국 시장 데이터 수집 (yfinance)
   ├── SPY, QQQ 수익률 (r1, r3, r5)
   ├── VIX 변동성 지표
   └── US10Y 금리 변화

3. Pre-open 리스크 평가 (live 모드만)
   ├── ES, NQ 선물 변화
   ├── VIX 선물 변화
   └── USD/KRW 환율 변화

4. 글로벌 레짐 계산
   ├── 한국 점수 (60% 가중치)
   ├── 미국 점수 (40% 가중치)
   └── 리스크 페널티 적용

5. 스캐너 연동
   ├── 장세별 cutoff 적용
   ├── horizon별 필터링
   └── 최종 후보 선별

6. DB 저장 및 캐싱
```

### **백테스트 플로우**
```
1. 기간 설정 (start_date ~ end_date)
2. 거래일 순회
   ├── DB에서 기존 레짐 로드
   ├── 없으면 v3 분석 실행 후 저장
   └── KOSPI 수익률 수집
3. 레짐별 통계 계산
   ├── 분포 (일수, 비율)
   ├── 성과 (평균, 표준편차, 승률)
   └── 전환 패턴 분석
4. 결과 리포트 생성
```

---

## ⚡ **성능 사양**

### **응답 시간 목표**
- **v3 장세 분석**: < 1.0초 (네트워크 포함)
- **한국 장세만**: < 0.3초
- **DB 저장/로드**: < 0.05초
- **스캐너 연동**: 기존 대비 +10% 이내

### **메모리 사용량**
- **추가 메모리**: ~15MB (yfinance 캐시)
- **피크 메모리**: 기존 대비 +8%
- **DB 연결**: 기존 풀 재사용

### **동시성**
- **분석 요청**: 동시 10개까지 처리 가능
- **DB 연결**: 기존 풀 공유
- **캐싱**: 5분 TTL로 중복 계산 방지

---

## 🛡️ **에러 처리 전략**

### **Graceful Degradation**
```python
# 미국 데이터 실패 시
if not us_data_valid:
    # v1 장세 분석으로 fallback
    return analyze_market_condition(date)

# DB 저장 실패 시  
try:
    upsert_regime(date, data)
except Exception as e:
    logger.warning(f"DB 저장 실패, 계속 진행: {e}")
    # 분석 결과는 정상 반환

# 네트워크 타임아웃 시
try:
    us_snapshot = get_us_prev_snapshot(date)
except Exception as e:
    us_snapshot = {'valid': False}  # 기본값 사용
```

### **데이터 검증**
```python
# 필수 키 검증
required_keys = ["spy_r3", "qqq_r3", "spy_r5", "qqq_r5", "vix", "ust10y_change"]
if not all(key in snapshot for key in required_keys):
    return default_neutral_result()

# None 값 안전 처리
spy_r3 = snapshot.get("spy_r3", 0) or 0
```

---

## 🔧 **설정 관리**

### **환경별 설정**
```python
# config_regime.py
REGIME_WEIGHTS = {
    'kr_weight': 0.6,      # 한국 시장 가중치
    'us_weight': 0.4,      # 미국 시장 가중치
    'preopen_penalty': {
        'watch': 0.5,      # 주의 단계 페널티
        'danger': 1.0      # 위험 단계 페널티
    }
}

REGIME_THRESHOLDS = {
    'bull_min': 2.0,       # bull 최소 점수
    'bear_max': -2.0,      # bear 최대 점수
    'crash_conditions': {
        'intraday_drop': -0.025,  # 장중 하락률 기준
        'vix_threshold': 35       # VIX 임계값
    }
}
```

### **운영 설정**
```python
# 캐시 설정
CACHE_TTL = 300  # 5분

# 네트워크 타임아웃
YFINANCE_TIMEOUT = 10  # 10초

# 백테스트 제한
MAX_BACKTEST_DAYS = 365  # 최대 1년
```

---

## 📈 **모니터링 지표**

### **핵심 KPI**
- **분석 성공률**: > 95%
- **응답 시간**: < 1초
- **DB 저장 성공률**: > 99%
- **미국 데이터 fetch 성공률**: > 90%

### **알림 조건**
- 분석 실패율 > 5%
- 응답 시간 > 2초
- DB 연결 실패
- yfinance API 장애

---

## 🚀 **배포 사양**

### **시스템 요구사항**
- **Python**: 3.9+ (권장)
- **메모리**: 기존 + 50MB
- **디스크**: 기존 + 100MB
- **네트워크**: yfinance API 접근 필요

### **의존성**
```
yfinance>=0.2.0
pandas>=1.5.0
numpy>=1.20.0
psycopg[binary]>=3.0.0
```

### **배포 체크리스트**
- [ ] DB 마이그레이션 실행
- [ ] 의존성 패키지 설치
- [ ] 설정 파일 배포
- [ ] 테스트 실행 확인
- [ ] 모니터링 설정
- [ ] 백업 계획 수립

---

*기술 사양서 작성일: 2025년 11월 22일*  
*버전: v3.0.0*  
*작성자: Amazon Q Developer*